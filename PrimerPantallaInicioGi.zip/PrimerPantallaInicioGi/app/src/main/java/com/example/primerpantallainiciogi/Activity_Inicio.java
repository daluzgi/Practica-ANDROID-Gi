package com.example.primerpantallainiciogi;

public class Activity_Inicio {
}
