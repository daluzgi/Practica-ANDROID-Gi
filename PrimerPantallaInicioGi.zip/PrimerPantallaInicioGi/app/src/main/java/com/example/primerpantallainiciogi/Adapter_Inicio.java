package com.example.primerpantallainiciogi;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_Inicio extends RecyclerView.Adapter<Adapter_Inicio.ViewHolderArtista> {

    private List<Artistas> listaDeArtistas;

    public AdapterGenero (List<Artistas>listaDeGeneros){
        this.listaDeArtistas = listaDeArtistas;
    }

    @NonNull
    @Override
    public ViewHolderGenero onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflador = LayoutInflater.from(parent.getContext());
        View view = inflador.inflate(R.layout.recyclerview_inicio, parent, false);
        ViewHolderArtista viewHolderArtista = new ViewHolderArtista(view);
        return viewHolderArtista;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderArtistas holder, int position) {
        Artistas unArtistaDeLaLista = this.listaDeArtistas.get(position);
        holder.cargarArtista(unArtistaDeLaLista);
    }

    @Override
    public int getItemCount() {
        return this.listaDeArtistas.size();
    }

    public class ViewHolderArtistas extends RecyclerView.ViewHolder {
        private TextView textViewArtistas;
        private ImageView imageViewFooFighters;
        private TextView textViewFoo_Fighters;

        public ViewHolderArtistas(@NonNull View itemView) {

            super(itemView);

            textViewArtistas = itemView.findViewById(R.id.recycler_text_artistas);
            imageViewFooFighters = itemView.findViewById(R.id.recycler_imagen_foofighters);
            textViewFoo_Fighters = itemView.findViewById(R.id.recycler_texto_foo_fighter);
        }

        //metodo que le enseña al view holder a cargar un objeto en este caso el villano
        public void cargarArtista (Artistas artistas){
            this.textViewArtistas.setText(artistas.getArtistas());
            imageViewFooFighters.setImageResource(artistas.getImagen());