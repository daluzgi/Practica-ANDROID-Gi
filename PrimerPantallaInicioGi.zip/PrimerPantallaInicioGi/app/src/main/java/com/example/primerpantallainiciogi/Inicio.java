package com.example.primerpantallainiciogi;

public class Inicio {
}
